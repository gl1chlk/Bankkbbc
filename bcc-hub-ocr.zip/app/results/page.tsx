"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BCCLogo } from "@/components/bcc-logo"
import { ArrowLeft, Download, FileText, Copy, CheckCircle, CreditCard, Building, DollarSign, User } from "lucide-react"
import Link from "next/link"

// Mock data for demonstration
const mockResults = [
  {
    id: "1",
    fileName: "bank_statement_january.pdf",
    processedAt: "2024-01-15T10:30:00Z",
    status: "completed",
    extractedData: {
      documentType: "Банковская выписка",
      accountNumber: "4400 1234 5678 9012",
      accountHolder: 'ТОО "Казахстан Бизнес"',
      bankName: "БЦК Банк",
      period: {
        from: "2024-01-01",
        to: "2024-01-31",
      },
      balance: {
        opening: 1250000.5,
        closing: 1450000.75,
      },
      transactions: [
        {
          date: "2024-01-05",
          description: "Поступление от клиента",
          amount: 350000.0,
          type: "credit",
        },
        {
          date: "2024-01-10",
          description: "Оплата поставщику",
          amount: -150000.25,
          type: "debit",
        },
      ],
    },
    rawText:
      'БАНКОВСКАЯ ВЫПИСКА\nБЦК БАНК\nСчет: 4400 1234 5678 9012\nВладелец: ТОО "Казахстан Бизнес"\nПериод: 01.01.2024 - 31.01.2024\n\nНачальный остаток: 1,250,000.50 тенге\nКонечный остаток: 1,450,000.75 тенге\n\nОПЕРАЦИИ:\n05.01.2024 Поступление от клиента +350,000.00\n10.01.2024 Оплата поставщику -150,000.25',
    confidence: 98.5,
  },
  {
    id: "2",
    fileName: "invoice_supplier_001.pdf",
    processedAt: "2024-01-15T10:32:00Z",
    status: "completed",
    extractedData: {
      documentType: "Счет-фактура",
      invoiceNumber: "INV-2024-001",
      supplier: 'ТОО "Поставщик Плюс"',
      customer: 'ТОО "Казахстан Бизнес"',
      issueDate: "2024-01-08",
      dueDate: "2024-01-22",
      totalAmount: 150000.25,
      currency: "KZT",
      items: [
        {
          description: "Офисные принадлежности",
          quantity: 100,
          unitPrice: 1500.0,
          total: 150000.0,
        },
      ],
    },
    rawText:
      'СЧЕТ-ФАКТУРА № INV-2024-001\nПоставщик: ТОО "Поставщик Плюс"\nПокупатель: ТОО "Казахстан Бизнес"\nДата выставления: 08.01.2024\nСрок оплаты: 22.01.2024\n\nТовары и услуги:\nОфисные принадлежности - 100 шт. × 1,500.00 = 150,000.00 тенге\n\nИтого к оплате: 150,000.25 тенге',
    confidence: 97.2,
  },
]

export default function ResultsPage() {
  const [selectedResult, setSelectedResult] = useState(mockResults[0])
  const [copiedField, setCopiedField] = useState<string | null>(null)

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text)
    setCopiedField(field)
    setTimeout(() => setCopiedField(null), 2000)
  }

  const downloadJSON = (result: (typeof mockResults)[0]) => {
    const dataStr = JSON.stringify(result.extractedData, null, 2)
    const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)
    const exportFileDefaultName = `${result.fileName.replace(/\.[^/.]+$/, "")}_extracted.json`

    const linkElement = document.createElement("a")
    linkElement.setAttribute("href", dataUri)
    linkElement.setAttribute("download", exportFileDefaultName)
    linkElement.click()
  }

  const downloadExcel = (result: (typeof mockResults)[0]) => {
    // Mock Excel download
    alert("Excel файл будет загружен (функция в разработке)")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/upload">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />К загрузке
                </Button>
              </Link>
              <BCCLogo />
            </div>
            <Badge variant="secondary">Результаты обработки</Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Page Title */}
          <div className="mb-8 animate-fade-in-up">
            <h1 className="text-3xl font-bold text-foreground mb-4">Результаты обработки документов</h1>
            <p className="text-muted-foreground text-lg">
              Извлеченные данные и структурированная информация из ваших документов
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Documents List */}
            <div className="lg:col-span-1">
              <Card className="animate-fade-in-up">
                <CardHeader>
                  <CardTitle className="text-lg">Обработанные документы</CardTitle>
                  <CardDescription>{mockResults.length} документов готово</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="space-y-2">
                    {mockResults.map((result) => (
                      <button
                        key={result.id}
                        onClick={() => setSelectedResult(result)}
                        className={`
                          w-full text-left p-4 rounded-lg transition-all duration-200 hover:bg-muted/50
                          ${selectedResult.id === result.id ? "bg-primary/10 border-l-4 border-primary" : "hover:bg-muted/30"}
                        `}
                      >
                        <div className="flex items-start space-x-3">
                          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                            <FileText className="h-4 w-4 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm text-foreground truncate">{result.fileName}</p>
                            <div className="flex items-center space-x-2 mt-1">
                              <Badge variant="secondary" className="text-xs">
                                {result.extractedData.documentType}
                              </Badge>
                              <span className="text-xs text-muted-foreground">{result.confidence}%</span>
                            </div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3">
              <Card className="animate-slide-in-right">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center">
                        <FileText className="h-5 w-5 mr-2 text-primary" />
                        {selectedResult.fileName}
                      </CardTitle>
                      <CardDescription className="flex items-center space-x-4 mt-2">
                        <span>Обработано: {new Date(selectedResult.processedAt).toLocaleString("ru-RU")}</span>
                        <Badge className="bg-primary text-primary-foreground">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          {selectedResult.confidence}% точность
                        </Badge>
                      </CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" onClick={() => downloadJSON(selectedResult)}>
                        <Download className="h-4 w-4 mr-2" />
                        JSON
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => downloadExcel(selectedResult)}>
                        <Download className="h-4 w-4 mr-2" />
                        Excel
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Tabs defaultValue="structured" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="structured">Структурированные данные</TabsTrigger>
                      <TabsTrigger value="raw">Исходный текст</TabsTrigger>
                      <TabsTrigger value="json">JSON</TabsTrigger>
                    </TabsList>

                    <TabsContent value="structured" className="mt-6">
                      <div className="space-y-6">
                        {/* Document Info */}
                        <div>
                          <h3 className="text-lg font-semibold text-foreground mb-4">Основная информация</h3>
                          <div className="grid md:grid-cols-2 gap-4">
                            <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                              <FileText className="h-5 w-5 text-primary" />
                              <div>
                                <p className="text-sm text-muted-foreground">Тип документа</p>
                                <p className="font-medium">{selectedResult.extractedData.documentType}</p>
                              </div>
                            </div>

                            {selectedResult.extractedData.accountNumber && (
                              <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                                <CreditCard className="h-5 w-5 text-primary" />
                                <div className="flex-1">
                                  <p className="text-sm text-muted-foreground">Номер счета</p>
                                  <div className="flex items-center space-x-2">
                                    <p className="font-medium">{selectedResult.extractedData.accountNumber}</p>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() =>
                                        copyToClipboard(selectedResult.extractedData.accountNumber!, "account")
                                      }
                                    >
                                      {copiedField === "account" ? (
                                        <CheckCircle className="h-4 w-4 text-primary" />
                                      ) : (
                                        <Copy className="h-4 w-4" />
                                      )}
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            )}

                            {selectedResult.extractedData.accountHolder && (
                              <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                                <User className="h-5 w-5 text-primary" />
                                <div>
                                  <p className="text-sm text-muted-foreground">Владелец счета</p>
                                  <p className="font-medium">{selectedResult.extractedData.accountHolder}</p>
                                </div>
                              </div>
                            )}

                            {selectedResult.extractedData.bankName && (
                              <div className="flex items-center space-x-3 p-3 bg-muted/30 rounded-lg">
                                <Building className="h-5 w-5 text-primary" />
                                <div>
                                  <p className="text-sm text-muted-foreground">Банк</p>
                                  <p className="font-medium">{selectedResult.extractedData.bankName}</p>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Financial Data */}
                        {selectedResult.extractedData.balance && (
                          <div>
                            <h3 className="text-lg font-semibold text-foreground mb-4">Финансовые данные</h3>
                            <div className="grid md:grid-cols-2 gap-4">
                              <Card>
                                <CardContent className="p-4">
                                  <div className="flex items-center space-x-3">
                                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                      <DollarSign className="h-5 w-5 text-primary" />
                                    </div>
                                    <div>
                                      <p className="text-sm text-muted-foreground">Начальный остаток</p>
                                      <p className="text-xl font-bold text-foreground">
                                        {selectedResult.extractedData.balance.opening.toLocaleString("ru-RU")} ₸
                                      </p>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                              <Card>
                                <CardContent className="p-4">
                                  <div className="flex items-center space-x-3">
                                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                      <DollarSign className="h-5 w-5 text-primary" />
                                    </div>
                                    <div>
                                      <p className="text-sm text-muted-foreground">Конечный остаток</p>
                                      <p className="text-xl font-bold text-foreground">
                                        {selectedResult.extractedData.balance.closing.toLocaleString("ru-RU")} ₸
                                      </p>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            </div>
                          </div>
                        )}

                        {/* Transactions */}
                        {selectedResult.extractedData.transactions && (
                          <div>
                            <h3 className="text-lg font-semibold text-foreground mb-4">Операции</h3>
                            <div className="space-y-3">
                              {selectedResult.extractedData.transactions.map((transaction, index) => (
                                <div
                                  key={index}
                                  className="flex items-center justify-between p-4 border border-border rounded-lg"
                                >
                                  <div className="flex items-center space-x-3">
                                    <div
                                      className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                                        transaction.type === "credit" ? "bg-primary/10" : "bg-destructive/10"
                                      }`}
                                    >
                                      <DollarSign
                                        className={`h-4 w-4 ${
                                          transaction.type === "credit" ? "text-primary" : "text-destructive"
                                        }`}
                                      />
                                    </div>
                                    <div>
                                      <p className="font-medium text-foreground">{transaction.description}</p>
                                      <p className="text-sm text-muted-foreground">{transaction.date}</p>
                                    </div>
                                  </div>
                                  <div
                                    className={`text-lg font-bold ${
                                      transaction.type === "credit" ? "text-primary" : "text-destructive"
                                    }`}
                                  >
                                    {transaction.type === "credit" ? "+" : ""}
                                    {transaction.amount.toLocaleString("ru-RU")} ₸
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="raw" className="mt-6">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">Распознанный текст</CardTitle>
                          <CardDescription>Исходный текст, извлеченный из документа</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="bg-muted/30 p-4 rounded-lg">
                            <pre className="whitespace-pre-wrap text-sm text-foreground font-mono">
                              {selectedResult.rawText}
                            </pre>
                          </div>
                          <div className="flex justify-end mt-4">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => copyToClipboard(selectedResult.rawText, "raw")}
                            >
                              {copiedField === "raw" ? (
                                <CheckCircle className="h-4 w-4 mr-2 text-primary" />
                              ) : (
                                <Copy className="h-4 w-4 mr-2" />
                              )}
                              Копировать текст
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>

                    <TabsContent value="json" className="mt-6">
                      <Card>
                        <CardHeader>
                          <CardTitle className="text-lg">JSON данные</CardTitle>
                          <CardDescription>Структурированные данные в формате JSON</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="bg-muted/30 p-4 rounded-lg">
                            <pre className="whitespace-pre-wrap text-sm text-foreground font-mono">
                              {JSON.stringify(selectedResult.extractedData, null, 2)}
                            </pre>
                          </div>
                          <div className="flex justify-end mt-4 space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                copyToClipboard(JSON.stringify(selectedResult.extractedData, null, 2), "json")
                              }
                            >
                              {copiedField === "json" ? (
                                <CheckCircle className="h-4 w-4 mr-2 text-primary" />
                              ) : (
                                <Copy className="h-4 w-4 mr-2" />
                              )}
                              Копировать JSON
                            </Button>
                            <Button size="sm" onClick={() => downloadJSON(selectedResult)}>
                              <Download className="h-4 w-4 mr-2" />
                              Скачать JSON
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
