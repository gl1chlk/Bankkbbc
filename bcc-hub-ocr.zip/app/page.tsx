"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { CenterCreditLogo } from "@/components/centercredit-logo"
import { AuthModal } from "@/components/auth-modal"
import { InfoModal } from "@/components/info-modal"
import { LanguageSelector } from "@/components/language-selector"
import { Upload, FileText, Zap, Shield, CheckCircle, ExternalLink } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const [isHovered, setIsHovered] = useState(false)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [showInfoModal, setShowInfoModal] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState("ru")

  const translations = {
    kk: {
      title: "Құжаттарды зияткерлік өңдеу",
      subtitle:
        "Жасанды интеллект арқылы банк құжаттарын автоматты түрде тану және құрылымдау үшін заманауи OCR платформасы",
      uploadDoc: "Құжатты жүктеу",
      learnMore: "Көбірек білу",
      authRequired: "Құжаттарды жүктеу үшін банк есептік жазбасы арқылы кіру қажет",
      features: "Платформа мүмкіндіктері",
      fastProcessing: "Жылдам өңдеу",
      dataStructuring: "Деректерді құрылымдау",
      security: "Қауіпсіздік",
      login: "Кіру",
      personalCabinet: "Жеке кабинет",
    },
    ru: {
      title: "Интеллектуальная обработка документов",
      subtitle:
        "Современная OCR-платформа для автоматического распознавания и структурирования банковских документов с использованием искусственного интеллекта",
      uploadDoc: "Загрузить документ",
      learnMore: "Узнать больше",
      authRequired: "Для загрузки документов требуется вход через банковский аккаунт",
      features: "Возможности платформы",
      fastProcessing: "Быстрая обработка",
      dataStructuring: "Структурирование данных",
      security: "Безопасность",
      login: "Войти",
      personalCabinet: "Личный кабинет",
    },
    en: {
      title: "Intelligent Document Processing",
      subtitle:
        "Modern OCR platform for automatic recognition and structuring of banking documents using artificial intelligence",
      uploadDoc: "Upload Document",
      learnMore: "Learn More",
      authRequired: "Bank account login required to upload documents",
      features: "Platform Features",
      fastProcessing: "Fast Processing",
      dataStructuring: "Data Structuring",
      security: "Security",
      login: "Login",
      personalCabinet: "Personal Cabinet",
    },
  }

  const t = translations[currentLanguage as keyof typeof translations]

  const handleUploadClick = () => {
    if (!isAuthenticated) {
      setShowAuthModal(true)
    }
  }

  const handleAuthSuccess = () => {
    setIsAuthenticated(true)
  }

  const handleTelegramChannel = () => {
    window.open("https://t.me/BANKbbc_bot", "_blank")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <CenterCreditLogo />
            <div className="flex items-center space-x-4">
              <LanguageSelector currentLanguage={currentLanguage} onLanguageChange={setCurrentLanguage} />
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAuthModal(true)}
                className="transition-all duration-300 hover:scale-105 hover:shadow-md active:scale-95 hover:bg-primary/10"
              >
                {isAuthenticated ? t.personalCabinet : t.login}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <div className="animate-fade-in-up">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6 text-balance">
              {t.title.split(" ").slice(0, -1).join(" ")}
              <span className="text-primary block">{t.title.split(" ").slice(-1)}</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">{t.subtitle}</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {isAuthenticated ? (
                <Link href="/upload">
                  <Button
                    size="lg"
                    className="text-lg px-8 py-6 transition-all duration-300 hover:scale-105 hover:shadow-lg active:scale-95 hover:bg-primary/90"
                    onMouseEnter={() => setIsHovered(true)}
                    onMouseLeave={() => setIsHovered(false)}
                  >
                    <Upload className="mr-2 h-5 w-5 transition-transform duration-300 group-hover:rotate-12" />
                    {t.uploadDoc}
                  </Button>
                </Link>
              ) : (
                <Button
                  size="lg"
                  className="text-lg px-8 py-6 transition-all duration-300 hover:scale-105 hover:shadow-lg active:scale-95 hover:bg-primary/90"
                  onClick={handleUploadClick}
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  <Upload className="mr-2 h-5 w-5 transition-transform duration-300 hover:rotate-12" />
                  {t.uploadDoc}
                </Button>
              )}
              <Button
                variant="outline"
                size="lg"
                className="text-lg px-8 py-6 bg-transparent transition-all duration-300 hover:scale-105 hover:shadow-lg active:scale-95 hover:bg-primary/10"
                onClick={() => setShowInfoModal(true)}
              >
                {t.learnMore}
              </Button>
            </div>
            {!isAuthenticated && (
              <p className="text-sm text-muted-foreground mt-4 animate-fade-in-up">
                <Shield className="inline h-4 w-4 mr-1" />
                {t.authRequired}
              </p>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">{t.features}</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Передовые технологии для эффективной обработки документов
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 hover:-translate-y-2">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 transition-all duration-300 hover:bg-primary/20 hover:scale-110">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>{t.fastProcessing}</CardTitle>
                <CardDescription>Обработка документов за секунды с точностью до 99.5%</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-primary mr-2" />
                    Поддержка PDF, JPG, PNG
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-primary mr-2" />
                    Пакетная обработка
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 hover:-translate-y-2">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 transition-all duration-300 hover:bg-primary/20 hover:scale-110">
                  <FileText className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>{t.dataStructuring}</CardTitle>
                <CardDescription>Автоматическое извлечение ключевых полей и создание JSON</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-primary mr-2" />
                    Банковские реквизиты
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-primary mr-2" />
                    Даты и суммы
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105 hover:-translate-y-2">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 transition-all duration-300 hover:bg-primary/20 hover:scale-110">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>{t.security}</CardTitle>
                <CardDescription>Банковский уровень защиты данных и соответствие стандартам</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-primary mr-2" />
                    Шифрование данных
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-primary mr-2" />
                    Аудит операций
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="animate-fade-in-up">
              <div className="text-3xl font-bold text-primary mb-2">99.5%</div>
              <div className="text-muted-foreground">Точность распознавания</div>
            </div>
            <div className="animate-fade-in-up">
              <div className="text-3xl font-bold text-primary mb-2">{"<3s"}</div>
              <div className="text-muted-foreground">Время обработки</div>
            </div>
            <div className="animate-fade-in-up">
              <div className="text-3xl font-bold text-primary mb-2">50+</div>
              <div className="text-muted-foreground">Типов документов</div>
            </div>
            <div className="animate-fade-in-up">
              <div className="text-3xl font-bold text-primary mb-2">24/7</div>
              <div className="text-muted-foreground">Доступность</div>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Information Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Техническая информация</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">Документация и техническая поддержка</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ExternalLink className="mr-2 h-5 w-5 text-primary" />
                  Telegram бот
                </CardTitle>
                <CardDescription>Автоматизированная поддержка и обработка запросов</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  onClick={handleTelegramChannel}
                  className="w-full transition-all duration-300 hover:scale-105 hover:shadow-md active:scale-95"
                >
                  <ExternalLink className="mr-2 h-4 w-4" />
                  Перейти к Telegram боту
                </Button>
                <p className="text-sm text-muted-foreground mt-2">Получите мгновенную помощь через наш ИИ-бот</p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-all duration-300 hover:scale-105">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5 text-primary" />
                  API документация
                </CardTitle>
                <CardDescription>Техническая документация для разработчиков</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  variant="outline"
                  className="w-full bg-transparent transition-all duration-300 hover:scale-105 hover:shadow-md active:scale-95 hover:bg-primary/10"
                  onClick={() => window.open("/api-docs", "_blank")}
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Открыть документацию
                </Button>
                <p className="text-sm text-muted-foreground mt-2">REST API для интеграции с вашими системами</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card/50 py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <CenterCreditLogo />
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <span className="text-sm text-muted-foreground">© 2024 CenterCredit Bank. Все права защищены.</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Authentication and Info Modals */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} onSuccess={handleAuthSuccess} />
      <InfoModal isOpen={showInfoModal} onClose={() => setShowInfoModal(false)} />
    </div>
  )
}
