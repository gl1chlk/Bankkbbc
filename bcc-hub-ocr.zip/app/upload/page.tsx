"use client"

import { useState, useCallback, useRef } from "react"
import { useDropzone } from "react-dropzone"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CenterCreditLogo } from "@/components/centercredit-logo"
import { LanguageSelector } from "@/components/language-selector"
import { Upload, FileText, X, CheckCircle, AlertCircle, ArrowLeft, Scan, Camera, Brain, Zap } from "lucide-react"
import Link from "next/link"

interface UploadedFile {
  id: string
  file: File
  status: "uploading" | "processing" | "completed" | "error"
  progress: number
  preview?: string
  ocrMethod?: string
}

type OCRMethod = "standard" | "paddle" | "layoutlm" | "donut" | "llm-enhanced"

export default function UploadPage() {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([])
  const [selectedOCRMethod, setSelectedOCRMethod] = useState<OCRMethod>("llm-enhanced")
  const [activeTab, setActiveTab] = useState("upload")
  const [isCameraActive, setIsCameraActive] = useState(false)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [currentLanguage, setCurrentLanguage] = useState("ru")
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const translations = {
    kk: {
      title: "Құжаттарды жүктеу және сканерлеу",
      subtitle: "Құжаттарды жүктеңіз немесе ЖИ арқылы автоматты өңдеу үшін сканерлеңіз",
      selectMethod: "Тану әдісін таңдаңыз",
      uploadFile: "Файлды жүктеу",
      scan: "Сканерлеу",
      selectFiles: "Файлдарды таңдаңыз",
      back: "Артқа",
      viewResults: "Нәтижелерді көру",
      completed: "Өңдеу аяқталды",
    },
    ru: {
      title: "Загрузка и сканирование документов",
      subtitle: "Загрузите документы или отсканируйте их для автоматической обработки с помощью ИИ",
      selectMethod: "Выберите метод распознавания",
      uploadFile: "Загрузить файл",
      scan: "Сканировать",
      selectFiles: "Выберите файлы",
      back: "Назад",
      viewResults: "Просмотреть результаты",
      completed: "Обработка завершена",
    },
    en: {
      title: "Document Upload and Scanning",
      subtitle: "Upload documents or scan them for automatic AI processing",
      selectMethod: "Select Recognition Method",
      uploadFile: "Upload File",
      scan: "Scan",
      selectFiles: "Select Files",
      back: "Back",
      viewResults: "View Results",
      completed: "Processing Completed",
    },
  }

  const t = translations[currentLanguage as keyof typeof translations]

  const ocrMethods = {
    standard: {
      name: "Стандартный OCR",
      icon: FileText,
      description: "Базовое распознавание • CER: ~5%",
      accuracy: "95%",
      languages: ["ru", "en"],
    },
    paddle: {
      name: "PaddleOCR",
      icon: Zap,
      description: "Высокоточное распознавание • CER: ~2%",
      accuracy: "98%",
      languages: ["ru", "en", "kk"],
    },
    layoutlm: {
      name: "LayoutLMV3",
      icon: Brain,
      description: "Понимание структуры документа • WER: ~1.5%",
      accuracy: "98.5%",
      languages: ["ru", "en", "kk"],
    },
    donut: {
      name: "Donut",
      icon: Brain,
      description: "End-to-end документ анализ • CER: ~1.2%",
      accuracy: "99%",
      languages: ["ru", "en", "kk"],
    },
    "llm-enhanced": {
      name: "LLM Enhanced",
      icon: Brain,
      description: "ИИ + контекст • Normalized Levenshtein: ~0.8%",
      accuracy: "99.5%",
      languages: ["ru", "en", "kk"],
    },
  }

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      const newFiles: UploadedFile[] = acceptedFiles.map((file) => ({
        id: Math.random().toString(36).substr(2, 9),
        file,
        status: "uploading",
        progress: 0,
        preview: file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined,
        ocrMethod: selectedOCRMethod,
      }))

      setUploadedFiles((prev) => [...prev, ...newFiles])

      newFiles.forEach((uploadedFile) => {
        simulateFileProcessing(uploadedFile.id)
      })
    },
    [selectedOCRMethod],
  )

  const simulateFileProcessing = (fileId: string) => {
    const uploadInterval = setInterval(() => {
      setUploadedFiles((prev) =>
        prev.map((file) => {
          if (file.id === fileId && file.status === "uploading") {
            const newProgress = Math.min(file.progress + Math.random() * 30, 100)
            if (newProgress >= 100) {
              clearInterval(uploadInterval)
              setTimeout(() => {
                setUploadedFiles((prev) =>
                  prev.map((f) => (f.id === fileId ? { ...f, status: "processing", progress: 0 } : f)),
                )
                simulateProcessing(fileId)
              }, 500)
              return { ...file, progress: 100, status: "uploading" }
            }
            return { ...file, progress: newProgress }
          }
          return file
        }),
      )
    }, 200)
  }

  const simulateProcessing = (fileId: string) => {
    const processingInterval = setInterval(() => {
      setUploadedFiles((prev) =>
        prev.map((file) => {
          if (file.id === fileId && file.status === "processing") {
            const newProgress = Math.min(file.progress + Math.random() * 25, 100)
            if (newProgress >= 100) {
              clearInterval(processingInterval)
              return { ...file, progress: 100, status: "completed" }
            }
            return { ...file, progress: newProgress }
          }
          return file
        }),
      )
    }, 300)
  }

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          facingMode: "environment",
        },
      })
      setStream(mediaStream)
      setIsCameraActive(true)

      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream
        videoRef.current.play()
      }
    } catch (error) {
      console.error("Ошибка доступа к камере:", error)
      alert("Не удалось получить доступ к камере. Проверьте разрешения.")
    }
  }

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach((track) => track.stop())
      setStream(null)
    }
    setIsCameraActive(false)
  }

  const captureImage = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current
      const video = videoRef.current
      const context = canvas.getContext("2d")

      canvas.width = video.videoWidth
      canvas.height = video.videoHeight

      if (context) {
        context.drawImage(video, 0, 0)

        canvas.toBlob(
          (blob) => {
            if (blob) {
              const file = new File([blob], `scan-${Date.now()}.jpg`, { type: "image/jpeg" })
              const newFile: UploadedFile = {
                id: Math.random().toString(36).substr(2, 9),
                file,
                status: "uploading",
                progress: 0,
                preview: URL.createObjectURL(blob),
                ocrMethod: selectedOCRMethod,
              }

              setUploadedFiles((prev) => [...prev, newFile])
              simulateFileProcessing(newFile.id)
              stopCamera()
              setActiveTab("upload")
            }
          },
          "image/jpeg",
          0.9,
        )
      }
    }
  }

  const removeFile = (fileId: string) => {
    setUploadedFiles((prev) => prev.filter((file) => file.id !== fileId))
  }

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "image/jpeg": [".jpg", ".jpeg"],
      "image/png": [".png"],
    },
    maxSize: 10 * 1024 * 1024,
    multiple: true,
  })

  const completedFiles = uploadedFiles.filter((file) => file.status === "completed")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button
                  variant="ghost"
                  size="sm"
                  className="transition-all duration-300 hover:scale-105 hover:shadow-md active:scale-95"
                >
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  {t.back}
                </Button>
              </Link>
              <CenterCreditLogo />
            </div>
            <div className="flex items-center space-x-4">
              <LanguageSelector currentLanguage={currentLanguage} onLanguageChange={setCurrentLanguage} />
              <Badge variant="secondary">{t.title}</Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 animate-fade-in-up">
            <h1 className="text-3xl font-bold text-foreground mb-4">{t.title}</h1>
            <p className="text-muted-foreground text-lg">{t.subtitle}</p>
          </div>

          <Card className="mb-6 animate-fade-in-up">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="h-5 w-5 mr-2 text-primary" />
                {t.selectMethod}
              </CardTitle>
              <CardDescription>Различные технологии OCR для максимальной точности</CardDescription>
            </CardHeader>
            <CardContent>
              <Select value={selectedOCRMethod} onValueChange={(value: OCRMethod) => setSelectedOCRMethod(value)}>
                <SelectTrigger className="w-full transition-all duration-300 hover:shadow-md focus:scale-105">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(ocrMethods).map(([key, method]) => {
                    const IconComponent = method.icon
                    return (
                      <SelectItem key={key} value={key} className="transition-colors duration-200 hover:bg-primary/10">
                        <div className="flex items-center space-x-2">
                          <IconComponent className="h-4 w-4" />
                          <div>
                            <div className="font-medium flex items-center space-x-2">
                              <span>{method.name}</span>
                              <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded">
                                {method.accuracy}
                              </span>
                            </div>
                            <div className="text-xs text-muted-foreground">{method.description}</div>
                            <div className="flex items-center space-x-1 mt-1">
                              {method.languages.map((lang) => (
                                <span key={lang} className="text-xs bg-muted px-1 py-0.5 rounded">
                                  {lang === "ru" ? "🇷🇺" : lang === "en" ? "🇺🇸" : "🇰🇿"} {lang.toUpperCase()}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </SelectItem>
                    )
                  })}
                </SelectContent>
              </Select>
              <div className="mt-4 p-3 bg-muted/50 rounded-lg">
                <h4 className="text-sm font-medium mb-2">Метрики точности выбранного метода:</h4>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-muted-foreground">Точность:</span>
                    <span className="ml-2 font-medium text-primary">
                      {ocrMethods[selectedOCRMethod as keyof typeof ocrMethods]?.accuracy}
                    </span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Языки:</span>
                    <span className="ml-2 font-medium">
                      {ocrMethods[selectedOCRMethod as keyof typeof ocrMethods]?.languages.length} языка
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger
                value="upload"
                className="flex items-center space-x-2 transition-all duration-300 hover:scale-105"
              >
                <Upload className="h-4 w-4" />
                <span>{t.uploadFile}</span>
              </TabsTrigger>
              <TabsTrigger
                value="scan"
                className="flex items-center space-x-2 transition-all duration-300 hover:scale-105"
              >
                <Scan className="h-4 w-4" />
                <span>{t.scan}</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="upload">
              <Card className="animate-fade-in-up">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Upload className="h-5 w-5 mr-2 text-primary" />
                    {t.selectFiles}
                  </CardTitle>
                  <CardDescription>
                    Поддерживаются форматы: PDF, JPG, PNG. Максимальный размер файла: 10MB
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div
                    {...getRootProps()}
                    className={`
                      border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all duration-300
                      ${
                        isDragActive
                          ? "border-primary bg-primary/5 scale-105 shadow-lg"
                          : "border-border hover:border-primary/50 hover:bg-muted/30 hover:scale-102"
                      }
                    `}
                  >
                    <input {...getInputProps()} />
                    <div className="flex flex-col items-center space-y-4">
                      <div
                        className={`
                        w-16 h-16 rounded-full flex items-center justify-center transition-all duration-300
                        ${isDragActive ? "bg-primary text-primary-foreground scale-110" : "bg-muted text-muted-foreground hover:scale-110"}
                      `}
                      >
                        <Upload className="h-8 w-8" />
                      </div>
                      {isDragActive ? (
                        <p className="text-lg font-medium text-primary">Отпустите файлы для загрузки</p>
                      ) : (
                        <>
                          <p className="text-lg font-medium text-foreground">
                            Перетащите файлы сюда или нажмите для выбора
                          </p>
                          <p className="text-sm text-muted-foreground">Можно загружать несколько файлов одновременно</p>
                        </>
                      )}
                      <Button
                        variant="outline"
                        className="mt-4 bg-transparent transition-all duration-300 hover:scale-105 hover:shadow-md active:scale-95"
                      >
                        Выбрать файлы
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="scan">
              <Card className="animate-fade-in-up">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Camera className="h-5 w-5 mr-2 text-primary" />
                    Сканирование документов
                  </CardTitle>
                  <CardDescription>Используйте камеру для сканирования документов в реальном времени</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center space-y-6">
                    <div className="w-full h-64 bg-muted rounded-lg flex items-center justify-center border-2 border-dashed border-border relative overflow-hidden transition-all duration-300 hover:shadow-lg">
                      {isCameraActive ? (
                        <video
                          ref={videoRef}
                          className="w-full h-full object-cover rounded-lg"
                          autoPlay
                          playsInline
                          muted
                        />
                      ) : (
                        <div className="text-center space-y-4">
                          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto transition-all duration-300 hover:scale-110">
                            <Camera className="h-8 w-8 text-primary" />
                          </div>
                          <p className="text-muted-foreground">Нажмите "Включить камеру" для начала сканирования</p>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {isCameraActive ? (
                        <>
                          <Button
                            onClick={captureImage}
                            className="flex items-center space-x-2 transition-all duration-300 hover:scale-105 hover:shadow-lg active:scale-95"
                          >
                            <Scan className="h-4 w-4" />
                            <span>Сканировать документ</span>
                          </Button>
                          <Button
                            variant="outline"
                            onClick={stopCamera}
                            className="flex items-center space-x-2 bg-transparent transition-all duration-300 hover:scale-105 hover:shadow-md active:scale-95"
                          >
                            <X className="h-4 w-4" />
                            <span>Остановить камеру</span>
                          </Button>
                        </>
                      ) : (
                        <Button
                          onClick={startCamera}
                          className="flex items-center space-x-2 transition-all duration-300 hover:scale-105 hover:shadow-lg active:scale-95"
                        >
                          <Camera className="h-4 w-4" />
                          <span>Включить камеру</span>
                        </Button>
                      )}
                    </div>

                    <div className="text-sm text-muted-foreground space-y-2">
                      <p>• Убедитесь, что документ хорошо освещен</p>
                      <p>• Держите камеру параллельно документу</p>
                      <p>• Используйте {ocrMethods[selectedOCRMethod].name} для обработки</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <canvas ref={canvasRef} style={{ display: "none" }} />

          {uploadedFiles.length > 0 && (
            <Card className="animate-slide-in-right">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center">
                    <FileText className="h-5 w-5 mr-2 text-primary" />
                    Обрабатываемые файлы ({uploadedFiles.length})
                  </span>
                  {completedFiles.length > 0 && (
                    <Link href="/results">
                      <Button
                        size="sm"
                        className="transition-all duration-300 hover:scale-105 hover:shadow-md active:scale-95"
                      >
                        {t.viewResults} ({completedFiles.length})
                      </Button>
                    </Link>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {uploadedFiles.map((uploadedFile) => {
                    const ocrMethod = ocrMethods[uploadedFile.ocrMethod as OCRMethod]
                    const IconComponent = ocrMethod?.icon || FileText

                    return (
                      <div
                        key={uploadedFile.id}
                        className="flex items-center space-x-4 p-4 border border-border rounded-lg hover:bg-muted/30 transition-all duration-300 hover:scale-102 hover:shadow-md"
                      >
                        <div className="flex-shrink-0">
                          {uploadedFile.preview ? (
                            <img
                              src={uploadedFile.preview || "/placeholder.svg"}
                              alt="Preview"
                              className="w-12 h-12 object-cover rounded-lg transition-transform duration-300 hover:scale-110"
                            />
                          ) : (
                            <div className="w-12 h-12 bg-muted rounded-lg flex items-center justify-center transition-transform duration-300 hover:scale-110">
                              <FileText className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                        </div>

                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-foreground truncate">{uploadedFile.file.name}</p>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <span>{(uploadedFile.file.size / 1024 / 1024).toFixed(2)} MB</span>
                            <span>•</span>
                            <div className="flex items-center space-x-1">
                              <IconComponent className="h-3 w-3" />
                              <span>{ocrMethod?.name}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center space-x-3">
                          {uploadedFile.status === "uploading" && (
                            <div className="flex items-center space-x-2">
                              <Progress value={uploadedFile.progress} className="w-24" />
                              <span className="text-sm text-muted-foreground">
                                {Math.round(uploadedFile.progress)}%
                              </span>
                            </div>
                          )}

                          {uploadedFile.status === "processing" && (
                            <div className="flex items-center space-x-2">
                              <Progress value={uploadedFile.progress} className="w-24" />
                              <Badge variant="secondary">Обработка ИИ</Badge>
                            </div>
                          )}

                          {uploadedFile.status === "completed" && (
                            <div className="flex items-center space-x-2">
                              <CheckCircle className="h-5 w-5 text-primary" />
                              <Badge className="bg-primary text-primary-foreground">Готово</Badge>
                            </div>
                          )}

                          {uploadedFile.status === "error" && (
                            <div className="flex items-center space-x-2">
                              <AlertCircle className="h-5 w-5 text-destructive" />
                              <Badge variant="destructive">Ошибка</Badge>
                            </div>
                          )}

                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeFile(uploadedFile.id)}
                            className="transition-all duration-300 hover:scale-110 active:scale-95"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {completedFiles.length > 0 && (
            <Card className="mt-8 animate-fade-in-up">
              <CardHeader>
                <CardTitle className="text-primary">{t.completed}</CardTitle>
                <CardDescription>Документы успешно обработаны с помощью ИИ и готовы к просмотру</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center transition-transform duration-300 hover:scale-110">
                      <CheckCircle className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{completedFiles.length} документов обработано</p>
                      <p className="text-sm text-muted-foreground">Данные извлечены и структурированы с помощью ИИ</p>
                    </div>
                  </div>
                  <Link href="/results">
                    <Button className="transition-all duration-300 hover:scale-105 hover:shadow-lg active:scale-95">
                      {t.viewResults}
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}
