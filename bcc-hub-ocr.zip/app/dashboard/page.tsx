"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BCCLogo } from "@/components/bcc-logo"
import {
  FileText,
  Upload,
  Clock,
  CheckCircle,
  AlertCircle,
  Download,
  User,
  Settings,
  BarChart3,
  Calendar,
  Search,
} from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"

// Mock data for dashboard
const mockStats = {
  totalDocuments: 156,
  processedToday: 12,
  successRate: 98.5,
  totalSavings: 2400, // hours saved
}

const mockRecentDocuments = [
  {
    id: "1",
    fileName: "bank_statement_january.pdf",
    type: "Банковская выписка",
    processedAt: "2024-01-15T10:30:00Z",
    status: "completed",
    confidence: 98.5,
  },
  {
    id: "2",
    fileName: "invoice_supplier_001.pdf",
    type: "Счет-фактура",
    processedAt: "2024-01-15T10:32:00Z",
    status: "completed",
    confidence: 97.2,
  },
  {
    id: "3",
    fileName: "contract_lease_2024.pdf",
    type: "Договор аренды",
    processedAt: "2024-01-15T09:45:00Z",
    status: "processing",
    confidence: null,
  },
  {
    id: "4",
    fileName: "receipt_office_supplies.jpg",
    type: "Чек",
    processedAt: "2024-01-15T09:20:00Z",
    status: "error",
    confidence: null,
  },
  {
    id: "5",
    fileName: "tax_declaration_2023.pdf",
    type: "Налоговая декларация",
    processedAt: "2024-01-14T16:15:00Z",
    status: "completed",
    confidence: 99.1,
  },
]

const mockMonthlyStats = [
  { month: "Янв", documents: 45, success: 44 },
  { month: "Фев", documents: 52, success: 51 },
  { month: "Мар", documents: 38, success: 37 },
  { month: "Апр", documents: 41, success: 40 },
  { month: "Май", documents: 35, success: 34 },
  { month: "Июн", documents: 48, success: 47 },
]

export default function DashboardPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedPeriod, setSelectedPeriod] = useState("week")

  const filteredDocuments = mockRecentDocuments.filter(
    (doc) =>
      doc.fileName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.type.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-4 w-4 text-primary" />
      case "processing":
        return <Clock className="h-4 w-4 text-yellow-500 animate-spin" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-destructive" />
      default:
        return <FileText className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-primary text-primary-foreground">
            <CheckCircle className="h-3 w-3 mr-1" />
            Готово
          </Badge>
        )
      case "processing":
        return (
          <Badge variant="secondary">
            <Clock className="h-3 w-3 mr-1" />
            Обработка
          </Badge>
        )
      case "error":
        return (
          <Badge variant="destructive">
            <AlertCircle className="h-3 w-3 mr-1" />
            Ошибка
          </Badge>
        )
      default:
        return <Badge variant="outline">Неизвестно</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <BCCLogo />
            <div className="flex items-center space-x-4">
              <Badge variant="secondary">Личный кабинет</Badge>
              <Button variant="ghost" size="sm">
                <User className="h-4 w-4 mr-2" />
                Профиль
              </Button>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Welcome Section */}
          <div className="mb-8 animate-fade-in-up">
            <h1 className="text-3xl font-bold text-foreground mb-2">Добро пожаловать в BCC Hub</h1>
            <p className="text-muted-foreground text-lg">
              Управляйте своими документами и отслеживайте статистику обработки
            </p>
          </div>

          {/* Stats Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card className="animate-fade-in-up hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{mockStats.totalDocuments}</p>
                    <p className="text-sm text-muted-foreground">Всего документов</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{mockStats.processedToday}</p>
                    <p className="text-sm text-muted-foreground">Обработано сегодня</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <BarChart3 className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{mockStats.successRate}%</p>
                    <p className="text-sm text-muted-foreground">Успешность</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="animate-fade-in-up hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Clock className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{mockStats.totalSavings}</p>
                    <p className="text-sm text-muted-foreground">Часов сэкономлено</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card className="mb-8 animate-slide-in-right">
            <CardHeader>
              <CardTitle>Быстрые действия</CardTitle>
              <CardDescription>Основные функции платформы</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <Link href="/upload">
                  <Button className="animate-pulse-green">
                    <Upload className="h-4 w-4 mr-2" />
                    Загрузить документы
                  </Button>
                </Link>
                <Link href="/results">
                  <Button variant="outline">
                    <FileText className="h-4 w-4 mr-2" />
                    Просмотреть результаты
                  </Button>
                </Link>
                <Button variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Экспорт данных
                </Button>
                <Button variant="outline">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Аналитика
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Recent Documents */}
            <div className="lg:col-span-2">
              <Card className="animate-fade-in-up">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Недавние документы</CardTitle>
                      <CardDescription>История обработки документов</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                        <Input
                          placeholder="Поиск документов..."
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="pl-10 w-64"
                        />
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {filteredDocuments.map((doc) => (
                      <div
                        key={doc.id}
                        className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/30 transition-colors"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                            {getStatusIcon(doc.status)}
                          </div>
                          <div>
                            <p className="font-medium text-foreground">{doc.fileName}</p>
                            <div className="flex items-center space-x-2 mt-1">
                              <Badge variant="outline" className="text-xs">
                                {doc.type}
                              </Badge>
                              <span className="text-xs text-muted-foreground">
                                {new Date(doc.processedAt).toLocaleString("ru-RU")}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          {doc.confidence && <span className="text-sm text-muted-foreground">{doc.confidence}%</span>}
                          {getStatusBadge(doc.status)}
                          {doc.status === "completed" && (
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-center mt-6">
                    <Button variant="outline">Показать больше</Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Analytics Sidebar */}
            <div className="space-y-6">
              {/* Monthly Chart */}
              <Card className="animate-slide-in-right">
                <CardHeader>
                  <CardTitle className="text-lg">Статистика по месяцам</CardTitle>
                  <CardDescription>Обработанные документы за последние 6 месяцев</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {mockMonthlyStats.map((stat, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">{stat.month}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-primary rounded-full transition-all duration-500"
                              style={{ width: `${(stat.success / stat.documents) * 100}%` }}
                            />
                          </div>
                          <span className="text-sm font-medium text-foreground">
                            {stat.success}/{stat.documents}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Document Types */}
              <Card className="animate-slide-in-right">
                <CardHeader>
                  <CardTitle className="text-lg">Типы документов</CardTitle>
                  <CardDescription>Распределение по категориям</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">Банковские выписки</span>
                      <Badge variant="secondary">45%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">Счета-фактуры</span>
                      <Badge variant="secondary">30%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">Договоры</span>
                      <Badge variant="secondary">15%</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-foreground">Прочие</span>
                      <Badge variant="secondary">10%</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Account Info */}
              <Card className="animate-slide-in-right">
                <CardHeader>
                  <CardTitle className="text-lg">Информация об аккаунте</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <User className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">Иван Петров</p>
                        <p className="text-sm text-muted-foreground">ivan.petrov@bcc.kz</p>
                      </div>
                    </div>
                    <div className="pt-3 border-t border-border">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-muted-foreground">План</span>
                        <Badge className="bg-primary text-primary-foreground">Корпоративный</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">Лимит документов</span>
                        <span className="text-sm font-medium text-foreground">1000/месяц</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
