export function BCCLogo({ className = "h-8 w-auto" }: { className?: string }) {
  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <div className="relative">
        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
          <span className="text-primary-foreground font-bold text-sm">BCC</span>
        </div>
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-secondary rounded-full animate-pulse-green"></div>
      </div>
      <div className="flex flex-col">
        <span className="font-bold text-foreground text-lg leading-none">BCC Hub</span>
        <span className="text-muted-foreground text-xs leading-none">OCR Platform</span>
      </div>
    </div>
  )
}
