export function CenterCreditLogo({ className = "h-8 w-auto" }: { className?: string }) {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className="relative">
        <img
          src="https://cdn.freebiesupply.com/logos/large/2x/centercredit-logo-png-transparent.png"
          alt="CenterCredit Bank"
          className="h-10 w-auto"
        />
        <div className="absolute -top-1 -right-1 w-3 h-3 bg-primary rounded-full animate-pulse-green"></div>
      </div>
      <div className="flex flex-col">
        <span className="font-bold text-foreground text-lg leading-none">CenterCredit</span>
        <span className="text-muted-foreground text-xs leading-none">OCR Platform</span>
      </div>
    </div>
  )
}
