"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shield, CheckCircle, Brain, Database, Clock, Users, TrendingUp, Award, Globe, Smartphone } from "lucide-react"

interface InfoModalProps {
  isOpen: boolean
  onClose: () => void
}

export function InfoModal({ isOpen, onClose }: InfoModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Подробная информация о платформе</DialogTitle>
          <DialogDescription>Полное руководство по возможностям OCR-платформы CenterCredit Bank</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="features" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="features">Возможности</TabsTrigger>
            <TabsTrigger value="technology">Технологии</TabsTrigger>
            <TabsTrigger value="security">Безопасность</TabsTrigger>
            <TabsTrigger value="support">Поддержка</TabsTrigger>
          </TabsList>

          <TabsContent value="features" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Brain className="h-5 w-5 mr-2 text-primary" />
                    Искусственный интеллект
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Современные алгоритмы машинного обучения для точного распознавания текста
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Нейронные сети для OCR
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Обработка естественного языка
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Автоматическая коррекция ошибок
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Database className="h-5 w-5 mr-2 text-primary" />
                    Структурирование данных
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Автоматическое извлечение и организация ключевых данных
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Банковские реквизиты
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Персональные данные
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Финансовые показатели
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <Clock className="h-5 w-5 mr-2 text-primary" />
                    Скорость обработки
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">Молниеносная обработка документов любого размера</p>
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-primary">{"<3s"}</div>
                      <div className="text-xs text-muted-foreground">Среднее время</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-primary">1000+</div>
                      <div className="text-xs text-muted-foreground">Документов/час</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center text-lg">
                    <TrendingUp className="h-5 w-5 mr-2 text-primary" />
                    Аналитика
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Детальная статистика и отчеты по обработанным документам
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      История операций
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Статистика точности
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Экспорт отчетов
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="technology" className="space-y-4">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Технологический стек</CardTitle>
                  <CardDescription>Современные технологии для максимальной эффективности</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <Brain className="h-8 w-8 text-primary mx-auto mb-2" />
                      <h4 className="font-semibold">Machine Learning</h4>
                      <p className="text-sm text-muted-foreground">TensorFlow, PyTorch</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <Database className="h-8 w-8 text-primary mx-auto mb-2" />
                      <h4 className="font-semibold">Cloud Computing</h4>
                      <p className="text-sm text-muted-foreground">AWS, Azure, GCP</p>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <Shield className="h-8 w-8 text-primary mx-auto mb-2" />
                      <h4 className="font-semibold">Security</h4>
                      <p className="text-sm text-muted-foreground">End-to-end encryption</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Поддерживаемые форматы</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {["PDF", "JPEG", "PNG", "TIFF", "BMP", "GIF", "WEBP", "SVG"].map((format) => (
                      <Badge key={format} variant="secondary" className="justify-center py-2">
                        {format}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="security" className="space-y-4">
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="h-5 w-5 mr-2 text-primary" />
                    Банковский уровень безопасности
                  </CardTitle>
                  <CardDescription>Соответствие международным стандартам безопасности</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <h4 className="font-semibold">Шифрование данных</h4>
                      <ul className="space-y-1 text-sm text-muted-foreground">
                        <li>• AES-256 шифрование</li>
                        <li>• TLS 1.3 для передачи</li>
                        <li>• End-to-end encryption</li>
                      </ul>
                    </div>
                    <div className="space-y-3">
                      <h4 className="font-semibold">Соответствие стандартам</h4>
                      <ul className="space-y-1 text-sm text-muted-foreground">
                        <li>• PCI DSS Level 1</li>
                        <li>• ISO 27001</li>
                        <li>• SOC 2 Type II</li>
                      </ul>
                    </div>
                  </div>
                  <div className="p-4 bg-primary/5 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Award className="h-5 w-5 text-primary mr-2" />
                      <span className="font-semibold">Сертификация НБ РК</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Платформа сертифицирована Национальным Банком Республики Казахстан
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="support" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-primary" />
                    Техническая поддержка
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <Clock className="h-4 w-4 text-primary mr-2" />
                      24/7 поддержка
                    </div>
                    <div className="flex items-center text-sm">
                      <Smartphone className="h-4 w-4 text-primary mr-2" />
                      +7 (727) 244-44-44
                    </div>
                    <div className="flex items-center text-sm">
                      <Globe className="h-4 w-4 text-primary mr-2" />
                      support@centercredit.kz
                    </div>
                  </div>
                  <Button variant="outline" className="w-full bg-transparent">
                    Связаться с поддержкой
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Обучение и документация</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Видео-уроки
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      API документация
                    </div>
                    <div className="flex items-center text-sm">
                      <CheckCircle className="h-4 w-4 text-primary mr-2" />
                      Примеры интеграции
                    </div>
                  </div>
                  <Button variant="outline" className="w-full bg-transparent">
                    Открыть документацию
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end pt-4">
          <Button onClick={onClose}>Закрыть</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
