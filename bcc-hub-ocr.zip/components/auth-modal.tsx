"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Shield, CreditCard, User, Lock, CheckCircle } from "lucide-react"

interface AuthModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export function AuthModal({ isOpen, onClose, onSuccess }: AuthModalProps) {
  const [step, setStep] = useState<"login" | "verify" | "success">("login")
  const [formData, setFormData] = useState({
    cardNumber: "",
    phone: "",
    smsCode: "",
  })

  const handleLogin = () => {
    // Simulate bank authentication
    setStep("verify")
    setTimeout(() => {
      setStep("success")
      setTimeout(() => {
        onSuccess()
        onClose()
        setStep("login")
      }, 2000)
    }, 3000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <Shield className="h-5 w-5 mr-2 text-primary" />
            Вход через банковский аккаунт
          </DialogTitle>
          <DialogDescription>
            Для безопасности все операции требуют аутентификации через CenterCredit Bank
          </DialogDescription>
        </DialogHeader>

        {step === "login" && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cardNumber">Номер карты</Label>
              <div className="relative">
                <CreditCard className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  className="pl-10"
                  value={formData.cardNumber}
                  onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value })}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Номер телефона</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="phone"
                  placeholder="+7 (777) 123-45-67"
                  className="pl-10"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
              </div>
            </div>
            <Button onClick={handleLogin} className="w-full">
              Войти в систему
            </Button>
            <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
              <Lock className="h-4 w-4" />
              <span>Защищено банковским шифрованием</span>
            </div>
          </div>
        )}

        {step === "verify" && (
          <div className="space-y-4 text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
              <Lock className="h-8 w-8 text-primary animate-pulse" />
            </div>
            <div>
              <h3 className="font-semibold">Подтверждение входа</h3>
              <p className="text-sm text-muted-foreground">SMS-код отправлен на номер {formData.phone}</p>
            </div>
            <Input
              placeholder="Введите код из SMS"
              className="text-center text-lg tracking-widest"
              value={formData.smsCode}
              onChange={(e) => setFormData({ ...formData, smsCode: e.target.value })}
            />
            <Badge variant="secondary" className="animate-pulse">
              Ожидание подтверждения...
            </Badge>
          </div>
        )}

        {step === "success" && (
          <div className="space-y-4 text-center">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold text-primary">Успешный вход!</h3>
              <p className="text-sm text-muted-foreground">Добро пожаловать в OCR-платформу CenterCredit</p>
            </div>
            <Badge className="bg-primary text-primary-foreground">Аутентификация завершена</Badge>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
